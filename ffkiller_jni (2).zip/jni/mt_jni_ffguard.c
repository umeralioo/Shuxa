#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include "xhook.h"

#define TAG "FFKN"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char *apkPath__ = NULL;
static const char *repPath__ = NULL;

static int interesting(const char *p) {
    if (!p) return 0;
    if (strstr(p, "maps")) return 1;
    if (strstr(p, "anogs")) return 1;
    if (strstr(p, "anort")) return 1;
    if (strstr(p, "ob_x")) return 1;
    if (strstr(p, "vm_rom")) return 1;
    if (strstr(p, "scan")) return 1;
    if (strstr(p, "report")) return 1;
    if (strstr(p, "tdm")) return 1;
    if (strstr(p, "complaint")) return 1;
    if (strstr(p, "origin")) return 1;
    if (strstr(p, "task")) return 1;
    if (strstr(p, ".so")) return 1;
    if (strstr(p, ".dex")) return 1;
    return 0;
}

int (*old_open)(const char *, int, mode_t);
static int openImpl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open(repPath__, flags, mode);
    if (interesting(pathname)) LOGE("open %s", pathname);
    return old_open(pathname, flags, mode);
}

int (*old_open64)(const char *, int, mode_t);
static int open64Impl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open64(repPath__, flags, mode);
    if (interesting(pathname)) LOGE("open64 %s", pathname);
    return old_open64(pathname, flags, mode);
}

int (*old_openat)(int, const char *, int, mode_t);
static int openatImpl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat(fd, repPath__, flags, mode);
    if (interesting(pathname)) LOGE("openat %s", pathname);
    return old_openat(fd, pathname, flags, mode);
}

int (*old_openat64)(int, const char *, int, mode_t);
static int openat64Impl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat64(fd, repPath__, flags, mode);
    if (interesting(pathname)) LOGE("openat64 %s", pathname);
    return old_openat64(fd, pathname, flags, mode);
}

int (*old_access)(const char *, int);
static int accessImpl(const char *pathname, int mode_) {
    if (interesting(pathname)) LOGE("access %s", pathname);
    return old_access(pathname, mode_);
}

FILE *(*old_fopen)(const char *, const char *);
static FILE *fopenImpl(const char *pathname, const char *mode_) {
    if (interesting(pathname)) LOGE("fopen %s", pathname);
    return old_fopen(pathname, mode_);
}

int (*old_stat)(const char *, struct stat *);
static int statImpl(const char *pathname, struct stat *buf) {
    if (interesting(pathname)) LOGE("stat %s", pathname);
    return old_stat(pathname, buf);
}

void *(*old_dlopen)(const char *, int);
static void *dlopenImpl(const char *filename, int flags) {
    if (filename) LOGE("dlopen %s", filename);
    else LOGE("dlopen NULL");
    return old_dlopen(filename, flags);
}

int (*old_connect)(int, const struct sockaddr *, socklen_t);
static int connectImpl(int fd, const struct sockaddr *addr, socklen_t len) {
    if (addr && addr->sa_family == AF_INET && len >= (socklen_t)sizeof(struct sockaddr_in)) {
        const struct sockaddr_in *a = (const struct sockaddr_in *)addr;
        char ip[16];
        unsigned int be = (unsigned int)a->sin_addr.s_addr;
        ip[0] = '\0';
        {
            unsigned char *b = (unsigned char *)&be;
            __android_log_print(ANDROID_LOG_ERROR, TAG, "connect %d.%d.%d.%d:%d",
                b[0], b[1], b[2], b[3], (int)ntohs(a->sin_port));
        }
    }
    return old_connect(fd, addr, len);
}

static void reg_all(void) {
    xhook_register(".*\\.so$", "openat64", (void *)openat64Impl, (void **)&old_openat64);
    xhook_register(".*\\.so$", "openat", (void *)openatImpl, (void **)&old_openat);
    xhook_register(".*\\.so$", "open64", (void *)open64Impl, (void **)&old_open64);
    xhook_register(".*\\.so$", "open", (void *)openImpl, (void **)&old_open);
    xhook_register(".*\\.so$", "access", (void *)accessImpl, (void **)&old_access);
    xhook_register(".*\\.so$", "fopen", (void *)fopenImpl, (void **)&old_fopen);
    xhook_register(".*\\.so$", "stat", (void *)statImpl, (void **)&old_stat);
    xhook_register(".*\\.so$", "dlopen", (void *)dlopenImpl, (void **)&old_dlopen);
    xhook_register(".*\\.so$", "connect", (void *)connectImpl, (void **)&old_connect);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm;
    (void)reserved;
    reg_all();
    xhook_refresh(0);
    LOGE("ffkn on");
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_ff_killer_Killer_hookApkPath(JNIEnv *env, __attribute__((unused)) jclass clazz, jstring apkPath, jstring repPath) {
    apkPath__ = (*env)->GetStringUTFChars(env, apkPath, 0);
    repPath__ = (*env)->GetStringUTFChars(env, repPath, 0);
    LOGE("ffkn paths set");
    reg_all();
    xhook_refresh(0);
}
